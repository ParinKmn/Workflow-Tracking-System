# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Document tracking system front end
* Version 0.0.1


### How do I get set up? ###

* node js to be installed in the system
* run npm install from the terminal
* run bower install from the terminal
* Files are located in the build folder

### Dependencies
* bootstrap